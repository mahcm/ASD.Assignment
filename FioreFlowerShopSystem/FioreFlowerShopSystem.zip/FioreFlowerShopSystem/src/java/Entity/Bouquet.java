/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ACER
 */
@Entity
@Table(name = "BOUQUET")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Bouquet.findAll", query = "SELECT b FROM Bouquet b")
    , @NamedQuery(name = "Bouquet.findByBouquetId", query = "SELECT b FROM Bouquet b WHERE b.bouquetId = :bouquetId")
    , @NamedQuery(name = "Bouquet.findByBouquetQuantity", query = "SELECT b FROM Bouquet b WHERE b.bouquetQuantity = :bouquetQuantity")})
public class Bouquet implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 5)
    @Column(name = "BOUQUET_ID")
    private String bouquetId;
    @Column(name = "BOUQUET_QUANTITY")
    private Integer bouquetQuantity;
    @JoinColumn(name = "STAFF_ID", referencedColumnName = "STAFF_ID")
    @ManyToOne(optional = false)
    private Staff staffId;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "bouquet")
    private Collection<ItemBouquet> itemBouquetCollection;

    public Bouquet() {
    }

    public Bouquet(String bouquetId) {
        this.bouquetId = bouquetId;
    }

    public String getBouquetId() {
        return bouquetId;
    }

    public void setBouquetId(String bouquetId) {
        this.bouquetId = bouquetId;
    }

    public Integer getBouquetQuantity() {
        return bouquetQuantity;
    }

    public void setBouquetQuantity(Integer bouquetQuantity) {
        this.bouquetQuantity = bouquetQuantity;
    }

    public Staff getStaffId() {
        return staffId;
    }

    public void setStaffId(Staff staffId) {
        this.staffId = staffId;
    }

    @XmlTransient
    public Collection<ItemBouquet> getItemBouquetCollection() {
        return itemBouquetCollection;
    }

    public void setItemBouquetCollection(Collection<ItemBouquet> itemBouquetCollection) {
        this.itemBouquetCollection = itemBouquetCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (bouquetId != null ? bouquetId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Bouquet)) {
            return false;
        }
        Bouquet other = (Bouquet) object;
        if ((this.bouquetId == null && other.bouquetId != null) || (this.bouquetId != null && !this.bouquetId.equals(other.bouquetId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entity.Bouquet[ bouquetId=" + bouquetId + " ]";
    }
    
}
