/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ItemController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ACER
 */
public class AddFreshFlowerTest {
    
    public AddFreshFlowerTest() {
    }
    
    @Before
    public void setUp() {
    }

    /**
     * Test of processRequest method, of class AddFreshFlower.
     */
    @Test
    public void testProcessRequest() throws Exception {
        System.out.println("processRequest");
        HttpServletRequest request = null;
        HttpServletResponse response = null;
        AddFreshFlower instance = new AddFreshFlower();
        instance.processRequest(request, response);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of doGet method, of class AddFreshFlower.
     */
    @Test
    public void testDoGet() throws Exception {
        System.out.println("doGet");
        HttpServletRequest request = null;
        HttpServletResponse response = null;
        AddFreshFlower instance = new AddFreshFlower();
        instance.doGet(request, response);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of doPost method, of class AddFreshFlower.
     */
    @Test
    public void testDoPost() throws Exception {
        System.out.println("doPost");
        HttpServletRequest request = null;
        HttpServletResponse response = null;
        AddFreshFlower instance = new AddFreshFlower();
        instance.doPost(request, response);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of getServletInfo method, of class AddFreshFlower.
     */
    @Test
    public void testGetServletInfo() {
        System.out.println("getServletInfo");
        AddFreshFlower instance = new AddFreshFlower();
        String expResult = "";
        String result = instance.getServletInfo();
        // TODO review the generated test code and remove the default call to fail.
    }
    
}
