/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ItemController;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author ACER
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({ItemController.AddFreshFlowerTest.class, ItemController.DeleteFreshFlowerTest.class, ItemController.SelectTest.class, ItemController.UpdateFreshFlowerTest.class, ItemController.ViewFreshFlowerDetailsTest.class, ItemController.SearchFreshFlowerTest.class, ItemController.LoadFreshFlowerListTest.class})
public class ItemControllerSuite {

    @Before
    public void setUp() throws Exception {
    }
    
}
